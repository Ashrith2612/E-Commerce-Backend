package com.example.SpringEcom.model.dto;

public record OrderitemRequest(
        int productId,
        int quantity
) {
}

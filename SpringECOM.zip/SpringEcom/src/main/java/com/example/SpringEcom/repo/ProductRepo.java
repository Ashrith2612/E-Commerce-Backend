package com.example.SpringEcom.repo;

import com.example.SpringEcom.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepo extends JpaRepository<Product , Integer> {

    //jpql as query..
    @Query("SELECT p from Product p WHERE " +
            "LOWER(p.name) LIKE LOWER(concat('%', :keyword, '%')) OR " +
            "LOWER(p.brand) LIKE LOWER(CONCAT('%', :keyword,'%')) OR " +
            "LOWER(p.category) LIKE LOWER(CONCAT('%', :keyword, '%'))" )
    List<Product> searchProducts(String keyword);
}

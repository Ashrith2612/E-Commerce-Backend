package com.example.SpringEcom.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity(name = "Orders")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Order {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(unique = true)
    private String orderId;

    private String customerName;

    private String email;

    private String status;

    private LocalDate odereDate;

    @OneToMany(mappedBy = "order" , cascade = CascadeType.ALL)
    private List<Orderitem> orderItems;

}

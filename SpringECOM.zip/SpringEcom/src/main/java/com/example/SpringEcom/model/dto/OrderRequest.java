package com.example.SpringEcom.model.dto;

import java.util.List;

public record OrderRequest(
        String customerName,
        String email,
        List<OrderitemRequest> items
) {
}
